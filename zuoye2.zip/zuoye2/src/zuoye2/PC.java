package zuoye2;
public class PC {
    CPU cpu;
    HardDisk harddisk;
    private int gutai = 100;
    int getPrivate(){
        return gutai;
    }
    void setCPU(CPU cpu){
        this.cpu=cpu;
    }
    void setHardDisk(HardDisk harddisk){
        this.harddisk=harddisk;
    }
    void shuchu(){
        System.out.println("CPU速度"+":"+cpu.getSpeed());
        System.out.println("CPU厂商"+":"+"AMD");
        System.out.println("硬盘容量"+":"+harddisk.getAmount());
        System.out.println("固态硬盘储存大小"+getPrivate()+"G");
    }
}