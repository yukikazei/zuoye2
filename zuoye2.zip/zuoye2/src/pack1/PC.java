package pack1;

public class PC {
        CPU cpu;
        HardDisk disk;
        private int gutai = 100;
        int getPrivate(){
                return gutai;
        }
        void setCPU(CPU cpu){
                this.cpu=cpu;
        }
        void setHardDisk(HardDisk disk){
                this.disk=disk;
        }
        void show(){
                System.out.println("CPU速度"+cpu.getSpeed());
                System.out.println("硬盘容量"+disk.getAmount());
                System.out.println("固态硬盘储存大小"+getPrivate()+"G");
        }
}