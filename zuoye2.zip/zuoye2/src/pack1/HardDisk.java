package pack1;

public class HardDisk {
    int amount;
    int getAmount() {
        return amount;
    }
    public void setAmount(int amount) {
        this.amount = amount;
    }
}