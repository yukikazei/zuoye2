package pack1;

public class CPU {
    int speed;
    int getSpeed(){
        return speed;
    }
    public void setSpeed(int speed){
        this.speed=speed;
    }
}